USE mathdb;

SELECT name FROM sys.databases;

SELECT * FROM operations;